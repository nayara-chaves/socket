### Client
Para utilizar o client, abra o projeto no visual studio e o compile
Depois execute o .Exe que o mesmo gerou

### Servidor
Para ultilizar o servidor execute os mesmos passos do client

### Testando a transferencia de arquivos
Abra a interface do servidor `Socket_Servidor.exe`
Clique em Iniciar servidor de atendimento.

Abra a interface do client `Socket_Cliente.exe`
Selecione o caminho do arquivo o qual voce quer fazer a transferencia
Clique em Conectar com o servidor e transferir o arquivo

O arquivo de resposta se encontrará na pasta de Arquivos presente no projeto

### Espero ajudar alguém assim como eu pesquisei sobre esse assunto
### TMJ <3
